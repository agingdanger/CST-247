﻿using Activity3.Models;
using Activity3.Services.Business;
using Activity3.Services.Utility;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace Activity3.Controllers
{
    [CustomAction]
    public class LoginController : Controller
    {
        //private static Logger logger = LogManager.GetLogger("myAppLoggerRules");
        //instantiates logger through custom class mylogger1
        private static MyLogger1 logger = MyLogger1.GetInstance();
        // GET: Login
        [HttpGet]
        public ActionResult Index()
        {
            return View("Login");
            //return @"<b>Just a test from Index</b>";
        }

        //controller method that passes user model to authenticate
        [HttpPost]
        public ActionResult Login(UserModel model)
        {
            //throws custom errors ,tries to pass model to security service
            try
            {
                MyLogger1.GetInstance().Info("Entering LoginController.DoLogin()");
                MyLogger1.GetInstance().Info("Parameters are: {0}", new JavaScriptSerializer().Serialize(model));

                logger.Info("Entering LoginController.Login()");

                if (!ModelState.IsValid)
                    return View("Login");

                SecurityService sec = new SecurityService();

                bool auth = sec.Authenticate(model);
                logger.Info("Parameters are:", new JavaScriptSerializer().Serialize(model));

                //if authenticator is true, and finds user then pass to login passed page / else login fail
                if (auth)
                {
                    MyLogger1.GetInstance().Info("Exit LoginController.DoLogin() with login passing");
                    return View("LoginPassed");

                }
                else
                {
                    MyLogger1.GetInstance().Info("Exit LoginController.DoLogin() with login failing");
                    return View("LoginFailed");
                }
            }
            //catch with error redirection rather then displaying broken code on user side / good error doc methodology
            catch (Exception e)
            {
                MyLogger1.GetInstance().Error("Exception LoginController.DoLogin() with message of {0}", e.Message);
                return View("Error");
            }
        }

        [HttpGet]
        [CustomAuthorization]
        public string Protected()
        {
            return "I am a protected method";
        }

        [HttpGet]
        public string GetUsers()
        {
            // Get the Default Memory Cache
            var cache = MemoryCache.Default;

            // Get Users from the Cache and if Users do not exist in the Cache then put them in Cache 
            List<UserModel> users = cache.Get("Users") as List<UserModel>;
            if (users == null)
            {
                // Log Message
                MyLogger1.GetInstance().Info("Creating Users and putting in the Cache.");

                // Create a List of Users
                users = new List<UserModel>();
                users.Add(new UserModel("Charles", "1234"));
                users.Add(new UserModel("Reuel", "1234"));
                users.Add(new UserModel("Harpreet", "1234"));

                // Save the Users in the Cache with a 60s expiration policy
                var policy = new CacheItemPolicy().AbsoluteExpiration = DateTimeOffset.Now.AddSeconds(60.0);
                cache.Set("Users", users, policy);
            }
            else
            {
                // Log Message
                MyLogger1.GetInstance().Info("Got Users from the Cache.");
            }

            // Return JSON Serialized list of users
            return new JavaScriptSerializer().Serialize(users);
        }
    }
}