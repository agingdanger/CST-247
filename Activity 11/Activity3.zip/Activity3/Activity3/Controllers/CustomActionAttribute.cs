﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Activity3.Services.Utility;

namespace Activity3.Controllers
{
    public class CustomActionAttribute : FilterAttribute, IActionFilter
    {
        // This method is called after an Action Method is executed
        void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
        {
            // Use our Logger Service to log when when we exit an Action Method
            //  NOTE: you would typically provide a configuration option to enable and disable this capability
            string name = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName + ":" + filterContext.ActionDescriptor.ActionName;
            MyLogger1.GetInstance().Info("Exiting this really weird Controller: " + name);
        }

        // This method is called before an Action Method is executed
        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Use our Logger Service to log when when we enter an Action Method
            //  NOTE: you would typically provide a configuration option to enable and disable this capability
            string name = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName + ":" + filterContext.ActionDescriptor.ActionName;
            MyLogger1.GetInstance().Info("Entering Controller: " + name);
        }
    }
}