﻿using Activity3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace HelloWorldService
{

    public class UserService : IUserService
    {
        List<UserModel> users = new List<UserModel>();

        public UserService()
        {
            // Create a List of Users
            users.Add(new UserModel("Chuck", "1234"));
            users.Add(new UserModel("Reuel", "1234"));
            users.Add(new UserModel("Harpreet", "1234"));
        }

        public DTO GetAllUsers()
        {

            DTO dto = new DTO(0, "OK", users);
            return dto;
        }

        public DTO GetUser(string id)
        {

            int index = Int32.Parse(id);
            if (index >= users.Count)
            {

                DTO dto = new DTO(-1, "User Does Not Exist", null);
                return dto;
            }
            else
            {
                // Initialize DTO with a User and return the DTO
                List<UserModel> user = new List<UserModel>();
                user.Add(users[index]);
                DTO dto = new DTO(0, "OK", user);
                return dto;
            }
        }
        //public string GetData(string value)
        //{
        //    return value;
        //    throw new NotImplementedException();
        //}

        //public CompositeType GetObjectModel(string id)
        //{
        //    if (id == null)
        //    {
        //        throw new ArgumentNullException("composite");
        //    }
        //    CompositeType composite = new CompositeType();
        //    composite.BoolValue = false;
        //    composite.StringValue = "Your value was " + id;
        //    return composite;
        //}

        //public string SayHello()
        //{
        //    return ("Hello There");
        //    throw new NotImplementedException();
        //}


    }
}
