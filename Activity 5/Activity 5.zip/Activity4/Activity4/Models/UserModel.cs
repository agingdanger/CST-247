﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Activity4.Models
{
    
    public class UserModel
    {
        //user model that contains basic attributes to give display examples on the test controller
        //again if this was an actual user model rather than example it would have things like password, location, login name, etc
        public UserModel(string Name, string Email, string Phone)
        {
            this.Name = Name;
            this.EmailAddress = Email;
            this.PhoneNumber = Phone;
        }

        public string Name { get; set; }

        public string EmailAddress { get; set; }

        public string PhoneNumber { get; set; }
    }
}