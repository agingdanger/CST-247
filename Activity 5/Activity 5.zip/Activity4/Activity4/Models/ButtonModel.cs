﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Activity4.Models
{
    public class ButtonModel
    {
        //simple button model
        //if we were pursuing larger product this would be much more refined with many attributes
        public bool State { get; set; }


        public ButtonModel(bool State)
        {
            this.State = State;
        }
    }
}