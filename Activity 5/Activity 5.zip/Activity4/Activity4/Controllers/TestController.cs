﻿using Activity4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Activity4.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            //this test controller initializes a list of users that passes to the Test view

            //this is used similarly in the buttoncontroller
            List<UserModel> users = new List<UserModel>();
            users.Add(new UserModel("Chuck Henderson", "Chender@gmail.com", "999-999-9999"));
            users.Add(new UserModel("Will Bower", "WBower@gmail.com", "888-888-8888"));
            return  View("Test", users);
        }
    }
}